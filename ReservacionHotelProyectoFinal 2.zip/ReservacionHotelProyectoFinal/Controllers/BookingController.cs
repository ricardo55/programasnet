using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ReservacionHotelExamen2.Models;

namespace ReservacionHotelExamen2.Controllers
{
    public class BookingController : Controller
    {
        private readonly ReservacionHotelContext _context;

        public BookingController(ReservacionHotelContext context)
        {
            _context = context;
        }

        // GET: Booking
        public async Task<IActionResult> Index()
        {
            var reservacionHotelContext = _context.Booking.Include(b => b.Customer);
            return View(await reservacionHotelContext.ToListAsync());
        }

        // GET: Booking/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var booking = await _context.Booking
                .Include(b => b.Customer)
                .FirstOrDefaultAsync(m => m.BookingID == id);
            if (booking == null)
            {
                return NotFound();
            }

            return View(booking);
        }

        // GET: Booking/Create
        public IActionResult Create()
        {
            //ViewData["CustomerID"] = new SelectList(_context.Customer, "CustomerID", "CustomerAdressCountry");
            ViewData["CustomerID"] = new SelectList(_context.Customer, "CustomerID","CustomerTitle");
           
            return View();
        }

        // POST: Booking/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BookingID,CustomerID,DateBookingMade,TimeBookingMade,BookedStartDate,BookedEndDate,TotalPaymentDueDate,TotalPaymentDueAmount,TotalPaymentMadeOn,BookingComments")] Booking booking)
        {
            if (ModelState.IsValid)
            {
                _context.Add(booking);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            //ViewData["CustomerID"] = new SelectList(_context.Customer, "CustomerID", "CustomerAdressCountry", booking.CustomerID);
            ViewData["CustomerID"] = new SelectList(_context.Customer, "CustomerID", "CustomerTitle", booking.CustomerID);
            return View(booking);
        }

        // GET: Booking/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var booking = await _context.Booking.FindAsync(id);
            if (booking == null)
            {
                return NotFound();
            }
            //ViewData["CustomerID"] = new SelectList(_context.Customer, "CustomerID", "CustomerAdressCountry", booking.CustomerID);
            ViewData["CustomerID"] = new SelectList(_context.Customer, "CustomerID", "CustomerTitle", booking.CustomerID);
            return View(booking);
        }

        // POST: Booking/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BookingID,CustomerID,DateBookingMade,TimeBookingMade,BookedStartDate,BookedEndDate,TotalPaymentDueDate,TotalPaymentDueAmount,TotalPaymentMadeOn,BookingComments")] Booking booking)
        {
            if (id != booking.BookingID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(booking);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookingExists(booking.BookingID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            //ViewData["CustomerID"] = new SelectList(_context.Customer, "CustomerID", "CustomerAdressCountry", booking.CustomerID);
            ViewData["CustomerID"] = new SelectList(_context.Customer, "CustomerID", "CustomerTitle", booking.CustomerID);
            
            return View(booking);
        }

        // GET: Booking/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var booking = await _context.Booking
                .Include(b => b.Customer)
                .FirstOrDefaultAsync(m => m.BookingID == id);
            if (booking == null)
            {
                return NotFound();
            }

            return View(booking);
        }

        // POST: Booking/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var booking = await _context.Booking.FindAsync(id);
            _context.Booking.Remove(booking);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BookingExists(int id)
        {
            return _context.Booking.Any(e => e.BookingID == id);
        }
    }
}
